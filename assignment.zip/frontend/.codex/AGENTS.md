# Overview

This is an application that allows users to upload files to canvases. The user will be notified when a file is uploaded to a canvas he or she has opened.

# General instructions

* Create reusable components instead of ad hoc styling with Tailwind. Promote variants of components resulting in different Tailwind classes.
