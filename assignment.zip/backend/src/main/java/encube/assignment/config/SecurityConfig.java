package encube.assignment.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
@EnableWebFluxSecurity
@Profile("!provision")
public class SecurityConfig {

    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
        return http
                .authorizeExchange(ex -> ex.anyExchange().permitAll())
                .httpBasic(ServerHttpSecurity.HttpBasicSpec::disable)
                .formLogin(formLogin -> {
                    formLogin.loginPage("/login");
                    formLogin.authenticationSuccessHandler((webFilterExchange, authentication) -> {
                        webFilterExchange.getExchange().getResponse().setStatusCode(org.springframework.http.HttpStatus.OK);
                        return webFilterExchange.getExchange().getResponse().setComplete();
                    });
                    formLogin.authenticationFailureHandler((webFilterExchange, exception) -> {
                        webFilterExchange.getExchange().getResponse().setStatusCode(org.springframework.http.HttpStatus.UNAUTHORIZED);
                        return webFilterExchange.getExchange().getResponse().setComplete();
                    });
                })
                .csrf(ServerHttpSecurity.CsrfSpec::disable) // often needed for POST in tests
                .build();
    }


}
