# Package encube.assignment.modules

This package contains modules that is sort of a microcosm of a micro-service platform. The modules are independent and
could be considered as separate services. The purpose of this division and isolation is to have independent, bounded
contexts that can be reused, tested in isolation with specific scalability concerns.